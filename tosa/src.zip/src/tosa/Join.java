package tosa;

import tosa.api.IDBTable;

/**
 * Created by IntelliJ IDEA.
 * User: alan
 * Date: 12/29/10
 * Time: 10:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class Join {
  private String _propName;
  private IDBTable _joinTable;
  private IDBTable _targetTable;

  public Join(String propName, IDBTable targetTable, IDBTable joinTable) {
    _propName = propName;
    _joinTable = joinTable;
    _targetTable = targetTable;
  }

  public String getPropName() {
    return _propName;
  }

  public IDBTable getJoinTable() {
    return _joinTable;
  }

  public IDBTable getTargetTable() {
    return _targetTable;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result
        + ((_joinTable == null) ? 0 : _joinTable.hashCode());
    result = prime * result + ((_propName == null) ? 0 : _propName.hashCode());
    result = prime * result
        + ((_targetTable == null) ? 0 : _targetTable.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Join other = (Join) obj;
    if (_joinTable == null) {
      if (other._joinTable != null)
        return false;
    } else if (!_joinTable.equals(other._joinTable))
      return false;
    if (_propName == null) {
      if (other._propName != null)
        return false;
    } else if (!_propName.equals(other._propName))
      return false;
    if (_targetTable == null) {
      if (other._targetTable != null)
        return false;
    } else if (!_targetTable.equals(other._targetTable))
      return false;
    return true;
  }

}
