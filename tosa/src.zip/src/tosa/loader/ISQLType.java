package tosa.loader;

import gw.lang.reflect.IType;

public interface ISQLType extends IType {
  SQLFileInfo getData();
}
