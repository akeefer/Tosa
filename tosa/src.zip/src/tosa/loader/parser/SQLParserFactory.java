package tosa.loader.parser;

/**
 * Created by IntelliJ IDEA.
 * User: alan
 * Date: 12/26/10
 * Time: 11:58 PM
 * To change this template use File | Settings | File Templates.
 */
public class SQLParserFactory {

  public static ISQLParser createParser() {
    // TODO - AHK
    return null;
  }
}
