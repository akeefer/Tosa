package tosa.loader.parser;

public enum TokenType {
  SYMBOL, STRING, NUMBER, OPERATOR, UNKNOWN, EOF;
}
