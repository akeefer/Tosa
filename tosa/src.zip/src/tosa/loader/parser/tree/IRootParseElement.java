package tosa.loader.parser.tree;

public interface IRootParseElement {
  String getPrimaryTableName();
}
